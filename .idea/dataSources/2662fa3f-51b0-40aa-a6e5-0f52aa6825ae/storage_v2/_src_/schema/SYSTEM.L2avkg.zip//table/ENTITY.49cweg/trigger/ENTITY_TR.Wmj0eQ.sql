create trigger ENTITY_TR
  before insert
  on ENTITY
  for each row
  declare
     foo number;
 begin
      if :new.id is null then
            select id_entity.nextval into foo from dual;
            :new.id := foo;
         end if;
    end;
/

