CREATE TRIGGER BI_SALGRADE
  BEFORE INSERT
  ON SALGRADE
  FOR EACH ROW
  begin   
  if :NEW."GRADE" is null then 
    select "SALGRADE_SEQ".nextval into :NEW."GRADE" from dual; 
  end if; 
end;
/

